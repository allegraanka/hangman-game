
class Game {
  constructor() {
    var game = this;
    this.wordKey = [];
    this.wordBlanksArr = [];
    this.lives = 3;
    this.word = "test";
    this.wordBlanks = "";
    this.word1 = null;
    this.word2 = null;
      this.words = [
        "hello",
        "basketball",
        "beer",
        "programming",
        "excellence",
        "flexibility",
        "tulip",
        "napkin",
        "posture",
        "cat",
        "table",
        "tiles",
        "lightening",
        "miller",
        "high",
        "life",
        "wizards",
        "late",
        "digital",
        "future",
        "visualize",
        "meowing",
        "united",
        "map",
        "taxes",
        "married",
        "wedding",
        "construction",
        "summer",
        "roofdeck",
        "control"
      ];
    this.totalWords = this.words.length;
  }
    getWord() {
      var game = this;
      game.word = game.words[Math.floor(Math.random() * game.totalWords)];
    }

    setBlanks() {
      var game = this;
      game.getWord();
        for (var i = 0; i < game.word.length; i++) {
          console.log('working');
          game.wordKey[i] = game.word.charAt(i);
          game.wordBlanksArr[i] = "_ ";
        }
        game.wordBlanks = game.wordBlanksArr.join("");
        document.getElementById("WORD").innerHTML = game.wordBlanks;
        document.getElementById("numLetters").innerHTML = game.word.length;
    }

    updateLetter(letter) {
      var game = this;
      game.changes = 0;
        for (var i = 0; i < game.word.length; i++) {
          game.wordKey[i] = game.word.charAt(i);
            if (game.word.charAt(i) == letter) {
              game.wordBlanksArr[i] = letter;
              game.changes += 1;
            }
        }
        if (game.changes < 1) {
          game.lives -= 1;
          document.getElementById("lives").innerHTML = game.lives;
          if (game.lives < 1) {
            document.getElementById("WORD").innerHTML = game.word1;
            alert("sorry, you're out of life. try another word!")
            window.location.reload();
          }
        }
      game.wordBlanks = game.wordBlanksArr.join("");
      document.getElementById("WORD").innerHTML = game.wordBlanks;

      game.word1 = game.wordKey.join("");
      game.word2 = game.wordBlanksArr.join("");

        if (game.word1 == game.word2) {
          alert("you won! loading a new game");
          window.location.reload();
        }
    }
}

var hangman = new Game();
hangman.getWord();
hangman.setBlanks();
