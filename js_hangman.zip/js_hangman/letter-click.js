// letter click functions - inside game class
    $(function(){
      $("#a").click(function(event){
        event.preventDefault();
        hangman.updateLetter("a");
      });
    });

    $(function(){
      $("#b").click(function(event){
        event.preventDefault();
        hangman.updateLetter("b");
      });
    });

    $(function(){
      $("#c").click(function(event){
        event.preventDefault();
        hangman.updateLetter("c");
      });
    });

    $(function(){
      $("#d").click(function(event){
        event.preventDefault();
        hangman.updateLetter("d");
      });
    });

    $(function(){
      $("#e").click(function(event){
        event.preventDefault();
        hangman.updateLetter("e");
      });
    });

    $(function(){
      $("#f").click(function(event){
        event.preventDefault();
        hangman.updateLetter("f");
      });
    });

    $(function(){
      $("#g").click(function(event){
        event.preventDefault();
        hangman.updateLetter("g");
      });
    });

    $(function(){
      $("#h").click(function(event){
        event.preventDefault();
        hangman.updateLetter("h");
      });
    });

    $(function(){
      $("#i").click(function(event){
        event.preventDefault();
        hangman.updateLetter("i");
      });
    });

    $(function(){
      $("#j").click(function(event){
        event.preventDefault();
        hangman.updateLetter("j");
      });
    });

    $(function(){
      $("#k").click(function(event){
        event.preventDefault();
        hangman.updateLetter("k");
      });
    });

    $(function(){
      $("#l").click(function(event){
        event.preventDefault();
        hangman.updateLetter("l");
      });
    });

    $(function(){
      $("#m").click(function(event){
        event.preventDefault();
        hangman.updateLetter("m");
      });
    });

    $(function(){
      $("#n").click(function(event){
        event.preventDefault();
        hangman.updateLetter("n");
      });
    });

    $(function(){
      $("#o").click(function(event){
        event.preventDefault();
        hangman.updateLetter("o");
      });
    });

    $(function(){
      $("#p").click(function(event){
        event.preventDefault();
        hangman.updateLetter("p");
      });
    });

    $(function(){
      $("#q").click(function(event){
        event.preventDefault();
        hangman.updateLetter("q");
      });
    });

    $(function(){
      $("#r").click(function(event){
        event.preventDefault();
        hangman.updateLetter("r");
      });
    });

    $(function(){
      $("#s").click(function(event){
        event.preventDefault();
        hangman.updateLetter("s");
      });
    });

    $(function(){
      $("#t").click(function(event){
        event.preventDefault();
        hangman.updateLetter("t");
      });
    });

    $(function(){
      $("#u").click(function(event){
        event.preventDefault();
        hangman.updateLetter("u");
      });
    });

    $(function(){
      $("#v").click(function(event){
        event.preventDefault();
        hangman.updateLetter("v");
      });
    });

    $(function(){
      $("#w").click(function(event){
        event.preventDefault();
        hangman.updateLetter("w");
      });
    });

    $(function(){
      $("#x").click(function(event){
        event.preventDefault();
        hangman.updateLetter("x");
      });
    });

    $(function(){
      $("#y").click(function(event){
        event.preventDefault();
        hangman.updateLetter("y");
      });
    });

    $(function(){
      $("#z").click(function(event){
        event.preventDefault();
        hangman.updateLetter("z");
      });
    });
